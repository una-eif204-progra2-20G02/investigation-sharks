//
// Created by acq07 on 09/10/2020.
//

#ifndef DECORATOR_DECORATOR_H
#define DECORATOR_DECORATOR_H
#include "ICar.h"
#include "Car.h"


class Decorator: public ICar{
public:
    double finalPrice() override;

    string availability() override;

    explicit Decorator(ICar *carDecorated);

    string toString() override;


protected:
    ICar* carDecorated;
};


#endif //DECORATOR_DECORATOR_H
