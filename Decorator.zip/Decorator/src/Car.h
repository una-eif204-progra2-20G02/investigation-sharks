//
// Created by acq07 on 09/10/2020.
//

#ifndef DECORATOR_CAR_H
#define DECORATOR_CAR_H
#include <iostream>
#include <sstream>
#include <iomanip>
#include "ICar.h"
using namespace std;

class Car: public ICar{
public:
    Car();

    Car(const string &model, double price, int passenger);

    const string &getModel() const;

    void setModel(const string &model);

    double getPrice() const;

    void setPrice(double price);

    int getPassenger() const;

    void setPassenger(int passenger);

    double finalPrice() override;

    string availability() override;

    string toString() override;


private:
    string model;
    double price;
    int passenger;
};

#endif //DECORATOR_CAR_H
