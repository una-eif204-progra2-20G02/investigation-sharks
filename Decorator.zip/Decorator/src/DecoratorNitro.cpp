//
// Created by acq07 on 09/10/2020.
//

#include "DecoratorNitro.h"


double DecoratorNitro::finalPrice() {
    return this->carDecorated->finalPrice()+5000;
}

string DecoratorNitro::availability() {
    return this->carDecorated->availability()+", Nitro added";
}

DecoratorNitro::DecoratorNitro(ICar* iCar): Decorator(iCar){
}

string DecoratorNitro::toString() {
    std::ostringstream output;
    output << std::fixed << std::setprecision(2);
    output << "Decorator Nitro"<<endl
           <<carDecorated->toString();

    return output.str();
}

string DecoratorNitro::nitroProvider() {
    return "The Fastest S.A";
}

