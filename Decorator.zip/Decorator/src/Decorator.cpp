//
// Created by acq07 on 09/10/2020.
//

#include "Decorator.h"

Decorator::Decorator(ICar *carDecorated) : carDecorated(carDecorated){

}

double Decorator::finalPrice() {
    return this->carDecorated->finalPrice();
}

string Decorator::availability() {
    return this->carDecorated->availability();
}

string Decorator::toString() {
    std::ostringstream output;
    output << std::fixed << std::setprecision(2);
    output <<"Object Decorated"<<endl
           << carDecorated->toString();
    return output.str();
}

