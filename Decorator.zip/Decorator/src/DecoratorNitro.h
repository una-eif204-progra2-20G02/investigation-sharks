//
// Created by acq07 on 09/10/2020.
//

#ifndef DECORATOR_DECORATORNITRO_H
#define DECORATOR_DECORATORNITRO_H
#include "Decorator.h"
#include "ICar.h"

class DecoratorNitro: public Decorator{
public:
    double finalPrice() override;

    string availability() override;

    explicit DecoratorNitro(ICar *carDecorated);

    string toString() override;

    static string nitroProvider();


};


#endif //DECORATOR_DECORATORNITRO_H
