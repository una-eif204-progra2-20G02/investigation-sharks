//
// Created by acq07 on 10/10/2020.
//

#ifndef UNTITLED1_DECORATORINSURANCE_H
#define UNTITLED1_DECORATORINSURANCE_H
#include "Decorator.h"


class DecoratorInsurance: public Decorator {
    public:
        double finalPrice() override;

        string availability() override;

        explicit DecoratorInsurance(ICar *carDecorated);

        string toString() override;

        static string insuranceCarrier();


};



#endif //UNTITLED1_DECORATORINSURANCE_H
