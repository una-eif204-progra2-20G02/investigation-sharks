//
// Created by acq07 on 10/10/2020.
//

#include "DecoratorInsurance.h"


double DecoratorInsurance::finalPrice() {
    return this->carDecorated->finalPrice()+3500;
}

string DecoratorInsurance::availability() {
    return this->carDecorated->availability()+", Vehicle with Insurance";
}

DecoratorInsurance::DecoratorInsurance(ICar* iCar): Decorator(iCar){

}

string DecoratorInsurance::toString() {
    std::ostringstream output;
    output << std::fixed << std::setprecision(2);
    output << "Decorator Insurance"<<endl
           <<  carDecorated->toString();

    return output.str();
}

string DecoratorInsurance::insuranceCarrier(){
    return "Protected S.A";
};
