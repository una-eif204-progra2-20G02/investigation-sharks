//
// Created by acq07 on 09/10/2020.
//

#ifndef DECORATOR_ICAR_H
#define DECORATOR_ICAR_H
#include <iostream>
using namespace std;

class ICar{
public:
    virtual double finalPrice() = 0;
    virtual string availability() = 0;
    virtual string toString() = 0;

    virtual ~ICar();
};

#endif //DECORATOR_ICAR_H
