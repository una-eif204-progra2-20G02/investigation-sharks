#include <iostream>
#include "Car.h"
#include "DecoratorNitro.h"
#include "DecoratorInsurance.h"

int main() {

    ICar* miCar= new Car("Chevrolet 2019", 40000, 5);
    cout<<miCar->toString();
    cout<<miCar->finalPrice()<<endl;
    cout<<miCar->availability()<<endl;

    cout<<"---------------------------------"<<endl;



//    Decoramos al auto con nitro
    miCar = new DecoratorNitro(miCar);


    cout<<miCar->toString();
    cout<<miCar->finalPrice()<<endl;
    cout<<miCar->availability()<<endl;


    cout<<DecoratorNitro::nitroProvider()<<endl;
    cout<<"---------------------------------"<<endl;

    //  Decoramos al auto con un seguro
    miCar = new DecoratorInsurance(miCar);
    cout<<miCar->toString();
    cout<<miCar->finalPrice()<<endl;
    cout<<miCar->availability()<<endl;

    cout<<DecoratorInsurance::insuranceCarrier();
//    // Tambien se puede hacer un uso de un TypeCast
//    cout<<((DecoratorNitro)miCar).nitroProvider();
    return 0;
}
