//
// Created by acq07 on 09/10/2020.
//

#include "Car.h"

Car::Car() {}

Car::Car(const string &model, double price, int passenger) : model(model), price(price),
passenger(passenger) {}


const string &Car::getModel() const {
    return model;
}

void Car::setModel(const string &model) {
    Car::model = model;
}

double Car::getPrice() const {
    return price;
}

void Car::setPrice(double price) {
    Car::price = price;
}

int Car::getPassenger() const {
    return passenger;
}

void Car::setPassenger(int passenger) {
    Car::passenger = passenger;
}


double Car::finalPrice() {
    return getPrice();
}

string Car::availability() {
    return "Available for purchase";
}

string Car::toString() {
    std::ostringstream output;
    output << std::fixed << std::setprecision(2);
    output << "Model: " << getModel()
           << ", Price: $" << getPrice()
           << ", Passengers: " << getPassenger()<<endl
           << "Final Price: $";
    return output.str();
}


