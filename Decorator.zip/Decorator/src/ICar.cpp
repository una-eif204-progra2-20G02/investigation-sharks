//
// Created by acq07 on 09/10/2020.
//

#include "ICar.h"

ICar::~ICar() {

}

